@extends('welcome')
@section('title', 'Diplômes & Formations')
@section('content')
<section class="expirience">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h2 class="title">Diplômes & Formations</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-md-10 offset-md-1">
          <ul class="timeline">
            <li class="timeline-event">
              <label class="timeline-event-icon"></label>
              <div class="timeline-event-copy">
                <p class="timeline-event-thumbnail">En 2014</p>
                <h3>Lycée EL KHAWARIZMI Tanger</h3>
                <h4>Baccalauréat en Sciences Physiques</h4>
              </div>
            </li>
            <li class="timeline-event">
              <label class="timeline-event-icon"></label>
              <div class="timeline-event-copy">
                <p class="timeline-event-thumbnail">
                  2014 - 2016
                </p>
                <h3>ISTA ISMONTIC Tanger</h3>
                <h4>Diplôme De Technicien Spécialisé En Développement</h4>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>
  @endsection