@extends('welcome')

@section('content')
    <section class="about">
      <div class="container">
        <div class="row">
          <div class="col-md-10 offset-md-1">
            <div class="row block_about">
              <div class="col-md-6 img_about">
                <img src="vendor/images/othmane.jpg" alt="" />
                <div class="social">
                  <ul class="list-inline icon-social">
                    <li>
                      <a
                        href="https://www.facebook.com/othmane.haymoud"
                        target="_blank"
                        ><i class="fab fa-facebook-f"></i
                      ></a>
                    </li>
                    <li>
                      <a href="mailto:outmansalama@gmail.com" target="_blank"
                        ><i class="fas fa-envelope"></i
                      ></a>
                    </li>
                    <li>
                      <a
                        href="https://www.instagram.com/otmanhaymoud/"
                        target="_blank"
                        ><i class="fab fa-instagram" aria-hidden="true"></i
                      ></a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="col-md-6 text_about">
                <h2>Othmane Hymoud</h2>
                <span class="sub_title">web design / web developer</span>
                <p>
                  Développeur web curieux, autonome, rigoureux, j'aime les
                  applications simples, rapides et efficaces. Un sens de
                  l'écoute et du service renforcé par 1 ans d'expérience à
                  travailler sur des projets variés, une expertise technique en
                  constante progression grâce à une formation perpétuelle.
                  Motivé par le besoin de faire toujours mieux et appuyé par de
                  solides bases acquises lors de mon parcours, je prends plaisir
                  à relever de nouveaux challenges.
                </p>
                <div class="dividire"></div>
                <p class="info"><strong>Age</strong> <span>23</span></p>
                <p class="info"><strong>ville</strong> <span>Tanger</span></p>
                <p class="info">
                  <strong>Téléphone</strong> <span>06 77 896 48 91</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="skils">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2 class="title">Compétences Professionnelles</h2>
          </div>
        </div>
        <div class="row ">
          <div class="col-md-10 offset-md-1">
            <div class="row skils_items">
              <div class="col-md-6">
                <div class="bar_group group_ident-11" max="100">
                  <p>Laravel</p>
                  <div class="bar_group__bar thin " value="60"></div>
                  <p>Wordpress</p>
                  <div class="bar_group__bar thin " value="60"></div>
                  <p>SQL</p>
                  <div class="bar_group__bar thin " value="90"></div>
                </div>
              </div>

              <div class="col-md-6">
                <div class="bar_group group_ident-11" max="100">
                  <p>html5 / css3</p>
                  <div class="bar_group__bar thin " value="80"></div>
                  <p>Jquery</p>
                  <div class="bar_group__bar thin " value="50"></div>
                  <p>Bootstrap</p>
                  <div class="bar_group__bar thin " value="85"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    



    
    @endsection