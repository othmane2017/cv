<?php $__env->startSection('title', "L'expérience Professionnelle"); ?>

<?php $__env->startSection('content'); ?>
<section class="expirience">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h2 class="title">L'expérience Professionnelle</h2>
        </div>
      </div>
      <div class="row">
        <div class="col-md-10 offset-md-1">
          <ul class="timeline">
            <li class="timeline-event">
              <label class="timeline-event-icon"></label>
              <div class="timeline-event-copy">
                <p class="timeline-event-thumbnail">Mars 2016 - Avril 2016</p>
                <h3>Victoire Communication</h3>
                <h4>Développeur Web</h4>
                <p>
                  J'ai développé des sites web avec html5 css3 et framework
                  Bootstrap
                </p>
              </div>
            </li>
            <li class="timeline-event">
              <label class="timeline-event-icon"></label>
              <div class="timeline-event-copy">
                <p class="timeline-event-thumbnail">
                  Février 2017 - Août 2017
                </p>
                <h3>Global Etik Tange</h3>
                <h4>Développeur Web</h4>
                <p>
                  J'ai développé des sites web en wordpress.
                </p>
              </div>
            </li>
            <li class="timeline-event">
              <label class="timeline-event-icon"></label>
              <div class="timeline-event-copy">
                <p class="timeline-event-thumbnail">Depuis Septembre 2017</p>
                <h3>Map-concepts Tanger</h3>
                <h4>Développeur Web</h4>
                <p>
                  J'ai développé des sites web en wordpress et Framework
                  Laravel 5
                </p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/wu-1/cv/resources/views/experience.blade.php ENDPATH**/ ?>