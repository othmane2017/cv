<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=`, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>cv Othmane Haymoud - <?php echo $__env->yieldContent('title'); ?></title>
    <link
      href="<?php echo e(asset('vendor/css/fonts.css')); ?>"
      rel="stylesheet"
      type="text/css"
      media="all"
    />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('vendor/css/lightgallery.css')); ?>" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('vendor/css/bootstrap.css')); ?>" />
    <link
      href="vendor/css/style.css"
      rel="stylesheet"
      type="text/css"
      media="all"
    />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('vendor/css/bars.css')); ?>" />
    <link
      href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap"
      rel="stylesheet"
    />
    <link
      href="https://fonts.googleapis.com/css?family=Caveat:400,700&display=swap&subset=cyrillic,cyrillic-ext,latin-ext"
      rel="stylesheet"
    />
  </head>
  <body>
    <header class="head">
      <div class="logo">
        <a href="<?php echo e(Route('home')); ?>"><h1><span>Othmane</span> Haymoud</h1></a>
      </div>
      <div class="menu-btn">
        <a class="btn-open" href="javascript:void(0)"></a>
    </div>
    <div class="overlay">
        <div class="menu">
            <ul>
                <li><a href="<?php echo e(Route('home')); ?>">Home</a></li>
                <li><a href="<?php echo e(Route('experience')); ?>">My Experience</a></li>
                <li><a href="<?php echo e(Route('deploma')); ?>">My Diplomas</a></li>
                <li><a href="<?php echo e(Route('my_projects')); ?>">My Projects</a></li>
            </ul>
        </div>
    </div>
    </header>
    <?php echo $__env->yieldContent('content'); ?>
    <footer>
        <p>Created with <i class="fas fa-heart"></i> by OTHMANE HAYMOUD © 2019</p>
      </footer>
      <script src="<?php echo e(asset('vendor/js/jquery-1.12.4.min.js')); ?>"></script>
      <script src="<?php echo e(asset('vendor/js/bootstrap.min.js')); ?>"></script>
      <script src="<?php echo e(asset('vendor/js/lightgallery.js')); ?>"></script>
      <script src="<?php echo e(asset('vendor/js/lg-fullscreen.min.js')); ?>"></script>
      <script src="<?php echo e(asset('vendor/js/lg-thumbnail.min.js')); ?>"></script>
      <script src="<?php echo e(asset('vendor/js/bars.js')); ?>"></script>
        <script src="<?php echo e(asset('vendor/js/isotope.pkgd.min.js')); ?>"></script>
      <script>
        var $container = $('.portfolioContainer');
            $container.isotope({
                filter: '*',
                animationOptions: {
                    duration: 750,
                    easing: 'linear',
                    queue: false
                }
            });
         $('.portfolioFilter a').click(function(){
                  $('.portfolioFilter .current').removeClass('current');
                  $(this).addClass('current');
          
                  var selector = $(this).attr('data-filter');
                  $container.isotope({
                      filter: selector,
                      animationOptions: {
                          duration: 750,
                          easing: 'linear',
                          queue: false
                      }
                  });
                  return false;
              }); 
              $('#gallery').lightGallery(); 
              $(document).ready(function () {
                $(".menu-btn a").click(function () {
                    $(".overlay").fadeToggle(200);
                    $(this).toggleClass('btn-open').toggleClass('btn-close');
                });
                $('.overlay').on('click', function () {
                    $(".overlay").fadeToggle(200);
                    $(".menu-btn a").toggleClass('btn-open').toggleClass('btn-close');
                });
                $('.menu a').on('click', function () {
                    $(".overlay").fadeToggle(200);
                    $(".menu-btn a").toggleClass('btn-open').toggleClass('btn-close');
                });
            });
      </script>
      <?php echo $__env->yieldContent('script'); ?>
    </body>
  </html>
  <?php /**PATH /var/www/html/wu-1/cv/resources/views/welcome.blade.php ENDPATH**/ ?>