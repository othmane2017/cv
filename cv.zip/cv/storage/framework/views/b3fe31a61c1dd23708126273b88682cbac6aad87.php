<?php $__env->startSection('title', "Tous Les Projets"); ?>
<?php $__env->startSection('content'); ?>
<section class="portfolio">
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1">
              <div class="portfolioFilter clearfix">
                  <a href="#" data-filter="*" class="current">Tous Les Projets</a>
                  <a href="#" data-filter=".lar">Laravel</a>
                  <a href="#" data-filter=".word">Word press</a>

              </div>
          </div>
        
        <div class="col-md-10 offset-md-1">
          <div  class="row portfolioContainer" id="gallery">
            <a href="vendor/images/pro1.jpg" data-sub-html="#link" class="col-md-4 col-12 portfolio word" data-cat="word">
                <div class="portfolio-wrapper">
                  <img src="vendor/images/pro1.jpg" alt="" />
                  <div class="label" >
                    <i class="fas fa-search"></i>
                    <span id="link" style="display:none"><button onclick="window.location.href='https://www.boulangerie-mille-feuille.com/'"> Boulangerie Mille Feuille </button></span>
                  </div>
                </div>
            </a>
            <a href="vendor/images/pro2.jpg" data-sub-html="#link1" class="col-md-4 col-12 portfolio word" data-cat="word">
                <div class="portfolio-wrapper">
                  <img src="vendor/images/pro2.jpg" alt="" />
                  <div class="label" >
                    <i class="fas fa-search"></i>
                    <span id="link1" style="display:none"><button onclick="window.location.href='https://www.france-vins.be/'"> France Vins </button></span>
                  </div>
                 </div>
            </a>
            <a href="vendor/images/pro3.jpg" data-sub-html="#link2" class="col-md-4 col-12 portfolio lar" data-cat="lar">
                <div class="portfolio-wrapper">
                  <img src="vendor/images/pro3.jpg" alt="" />
                  <div class="label" >
                    <i class="fas fa-search"></i>
                    <span id="link2" style="display:none"><button onclick="window.location.href='http://alilou.ma/'"> Alilou </button></span>
                  </div>
                </div>
            </a>
            <a href="vendor/images/pro4.jpg" data-sub-html="#link3" class="col-md-4 col-12 portfolio lar" data-cat="lar">
                <div class="portfolio-wrapper">
                  <img src="vendor/images/pro4.jpg" alt="" />
                  <div class="label" >
                    <i class="fas fa-search"></i>
                    <span id="link3" style="display:none"><button onclick="window.location.href='http://www.murmure.ma/'"> Murmure </button></span>
                  </div>
                </div>
            </a>
            <a href="vendor/images/pro5.jpg" data-sub-html="#link4" class="col-md-4 col-12 portfolio lar" data-cat="lar">
              <div class="portfolio-wrapper">
                <img src="vendor/images/pro5.jpg" alt="" />
                <div class="label" >
                  <i class="fas fa-search"></i>
                  <span id="link4" style="display:none"><button onclick="window.location.href='http://idealdiet.ma/ '"> idealdiet </button></span>
                </div>
              </div>
          </a>
          </div>
        </div>
      </div>
      </div>
  </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/wu-1/cv/resources/views/my_projects.blade.php ENDPATH**/ ?>